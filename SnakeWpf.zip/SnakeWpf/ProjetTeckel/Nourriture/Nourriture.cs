﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Shapes;

namespace ProjetTeckel.Moteur
{
    internal class Nourriture
    {
        public class ChocolatInfo
        {
            public int Numero { get; set; }
            public Rectangle Rectangle { get; set; }
        }
        public class OsInfo
        {
            public int Numero { get; set; }
            public Rectangle Rectangle { get; set; }
        }
    }
}
