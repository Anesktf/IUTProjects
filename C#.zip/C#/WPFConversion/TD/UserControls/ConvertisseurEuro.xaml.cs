﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TD.Services;
using TD.Models;
using System.ComponentModel;

namespace TD.UserControls
{
    /// <summary>
    /// Logique d'interaction pour ConvertisseurEuro.xaml
    /// </summary>
    public partial class ConvertisseurEuro : UserControl
    {
        private ObservableCollection<Devise>? collectionDevises;
        public ObservableCollection<Devise>? CollectionDevises
        {

            get { return collectionDevises; }
            set { collectionDevises = value; }

        }
        private Devise deviseSelectionnee;

        public Devise DeviseSelectionnee
        {
            get { return deviseSelectionnee; }
            set { deviseSelectionnee = value; }
        }

        private double montant;

        public double Montant
        {
            get { return montant; }
            set { montant = value; }
        }

        private double montantConverti;

        public double MontantConverti
        {
            get { return montantConverti; }
            set
            {
                montantConverti = value;
                //OnPropertyChanged(nameof(MontantConverti));
            }
        }
       
        public ConvertisseurEuro()
        {
            InitializeComponent();
            this.DataContext = this;
            Service service = new Service();
            CollectionDevises = service.DeserializeFile();
        }

        private void BtConvertirDeviseEuro_Click(object sender, RoutedEventArgs e)
        {
            MontantConverti = Math.Round(Montant * DeviseSelectionnee.Taux, 2);
            result.Text = MontantConverti.ToString()+" €";
        }
    }
}
