﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

using TD1Debug;

ExoDebug exo = new ExoDebug();
exo.Exercice3();
