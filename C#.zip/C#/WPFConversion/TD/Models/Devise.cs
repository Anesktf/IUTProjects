﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TD.Models
{
    public class Devise
    {
		private string nomDevise;

		public string NomDevise
		{
			get { return nomDevise; }
			set { nomDevise = value; }

		}
		private double taux;

		public double Taux
		{
			get { return taux; }
			set { if (value <= 0) throw new ArgumentException("Impossible d'ajouter la devise");
				taux = value; }
		}

        public override bool Equals(object? obj)
        {
            return base.Equals(obj);
        }

        public override string? ToString()
        {
            return this.NomDevise;
        }
    }
}
