
namespace Calculatrice
{
    public static class Calcul
    {
        public static double Addition(double nb1, double nb2)
        {
            return nb1 + nb2;
        }

        public static double Soustraction(double nb1, double nb2)
        {
            return nb1 - nb2;
        }

        public static double Multiplication(double nb1, double nb2)
        {
            return nb1 * nb2;
        }


        public static double Divison(double nb1, double nb2)
        {
            if (nb2 == 0)  
            {
                throw new DivideByZeroException();
            }
            return nb1 / nb2;
        }

        public static double Factorielle(double nb1)
        {
            if (nb1 < 0)
            {
                throw new ArgumentException("La valeur doit �tre sup�rieure ou �gale � 0");
            }

            if (nb1 == 0)
            {
                return 1;  // La factorielle de 0 est d�finie comme 1
            }

            double result = 1;

            for (int i = 1; i <= nb1; i++)
            {
                result *= i;
            }

            return result;
        }


    }

}
