﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Calculatrice;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculatrice.Tests
{
    [TestClass()]
    public class CalculTests
    {

        [TestMethod()]
        public void AdditionTest_AvecValeur_1_2_Retourne3()
        {
            //Arrange
            Double a = 1.0;
            Double b = 2.0;
            //Act
            Double resultat = Calcul.Addition(a, b);
            //Assert
            Assert.AreEqual(3.0, resultat, "Test non OK. La valeur doit être égale à 3");
        }

        [TestMethod()]
        public void AdditionTest_AvecValeur_1_moins2_RetourneMoins1()
        {
            //Arrange
            Double a = 1.0;
            Double b = -2.0;
            //Act
            Double resultat = Calcul.Addition(a, b);
            //Assert
            Assert.AreEqual(-1.0, resultat, "Test non OK. La valeur doit être égale à -1");
        }

        [TestMethod()]
        public void AdditionTest_AvecValeur_0_0_Retourne0()
        {
            //Arrange
            Double a = 0;
            Double b = 0;
            //Act
            Double resultat = Calcul.Addition(a, b);
            //Assert
            Assert.AreEqual(0, resultat, "Test non OK. La valeur doit être égale à 0");
        }

        [TestMethod()]
        public void AdditionTest_AvecValeur_moins1_moins2_RetourneMoins3()
        {
            //Arrange
            Double a = -1.0;
            Double b = -2.0;
            //Act
            Double resultat = Calcul.Addition(a, b);
            //Assert
            Assert.AreEqual(-3.0, resultat, "Test non OK. La valeur doit être égale à -3");
        }

        [TestMethod()]
        public void DivisionTest_AvecValeur_1_2_Retourne0_virgule_5()
        {
            //Arrange
            Double a = 1.0;
            Double b = 2.0;
            //Act
            Double resultat = Calcul.Divison(a, b);
            //Assert
            Assert.AreEqual(0.5, resultat, "Test non OK. La valeur doit être égale à 0.5");
        }

        [TestMethod()]
        public void DivisionTest_AvecValeur_1_moins2_RetourneMoins0_virgule_5()
        {
            //Arrange
            Double a = 1.0;
            Double b = -2.0;
            //Act
            Double resultat = Calcul.Divison(a, b);
            //Assert
            Assert.AreEqual(-0.5, resultat, "Test non OK. La valeur doit être égale à -0.5");
        }

        [TestMethod()]
        public void DivisionTest_AvecValeur_0_1_Retourne0()
        {
            //Arrange
            Double a = 0.0;
            Double b = 1.0;
            //Act
            Double resultat = Calcul.Divison(a, b);
            //Assert
            Assert.AreEqual(0, resultat, "Test non OK. La valeur doit être égale à -0.5");
        }

        [TestMethod()]
        [ExpectedException(typeof(DivideByZeroException))]
        public void Division_AvecValeur_1_0_RetourneDivideByZeroException()
        {
            // Arrange
            Double a = 1.0;
            Double b = 0.0;
            // Act levant l’exception attendue de type MonException
            Double resultat = Calcul.Divison(a, b);
        }

        [TestMethod()]
        public void FactorielleTest_AvecValeur0_Donne1()
        {
            // Arrange
            Double a = 0;
            // Act 
            Double resultat = Calcul.Factorielle(a);
            //Assert
            Assert.AreEqual(1, resultat, "Test non OK. La valeur doit être égale à 1");
        }

        [TestMethod()]
        public void FactorielleTest_AvecValeur1_Donne1()
        {
            // Arrange
            Double a = 1;
            // Act 
            Double resultat = Calcul.Factorielle(a);
            //Assert
            Assert.AreEqual(1, resultat, "Test non OK. La valeur doit être égale à 1");
        }

        [TestMethod()]
        public void FactorielleTest_AvecValeur10_Donne3628800()
        {
            // Arrange
            Double a = 10;
            // Act 
            Double resultat = Calcul.Factorielle(a);
            //Assert
            Assert.AreEqual(3628800, resultat, "Test non OK. La valeur doit être égale à 1");
        }


        [TestMethod()]
        [ExpectedException(typeof(ArgumentException))]
        public void FactorielleTest_AvecValeur_inf0_exception()
        {
            // Arrange
            Double a = -1.0;
            // Act levant l’exception attendue de type MonException
            Double resultat = Calcul.Factorielle(a);
        }

        [TestMethod()]
        public void SoustractionTest_AvecValeur1_2_Donne2()
        {
            // Arrange
            Double a = 2.0;
            Double b = 1.0;
            // Act levant l’exception attendue de type MonException
            Double resultat = Calcul.Soustraction(a, b);
            Assert.AreEqual(1, resultat, "Test non OK. La valeur doit être égale à 1");
        }

        [TestMethod()]
        public void SoustractionTest_AvecValeur0_2_Donne0()
        {
            // Arrange
            Double a = 0.0;
            Double b = 2.0;
            // Act levant l’exception attendue de type MonException
            Double resultat = Calcul.Soustraction(a, b);
            Assert.AreEqual(-2, resultat, "Test non OK. La valeur doit être égale à -2");
        }

        [TestMethod()]
        public void SoustractionTest_AvecValeurMoins2_Moins1_Donne3()
        {
            // Arrange
            Double a = 2.0;
            Double b = -1.0;
            // Act levant l’exception attendue de type MonException
            Double resultat = Calcul.Soustraction(a, b);
            Assert.AreEqual(3, resultat, "Test non OK. La valeur doit être égale à 3");
        }

        [TestMethod()]
        public void MultiplicationTest_AvecValeur2_1_Donne2()
        {
            // Arrange
            Double a = 2.0;
            Double b = 1.0;
            // Act levant l’exception attendue de type MonException
            Double resultat = Calcul.Multiplication(a, b);
            Assert.AreEqual(2, resultat, "Test non OK. La valeur doit être égale à 2");
        }

        [TestMethod()]
        public void MultiplicationTest_AvecValeurMoins2_1_DonneMoins2()
        {
            // Arrange
            Double a = -2.0;
            Double b = 1.0;
            // Act levant l’exception attendue de type MonException
            Double resultat = Calcul.Multiplication(a, b);
            Assert.AreEqual(-2, resultat, "Test non OK. La valeur doit être égale à -2");
        }

        [TestMethod()]
        public void MultiplicationTest_AvecValeur0_10_Donne0()
        {
            // Arrange
            Double a = 0.0;
            Double b = 10.0;
            // Act levant l’exception attendue de type MonException
            Double resultat = Calcul.Multiplication(a, b);
            Assert.AreEqual(0, resultat, "Test non OK. La valeur doit être égale à 0");
        }


    }
}