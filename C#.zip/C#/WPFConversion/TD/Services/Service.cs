﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TD.Models;
using System.Text.Json;
using System.IO;
using System.Collections.ObjectModel;
using System.ComponentModel;


namespace TD.Services
{
    public class Service
    {
        

        public ObservableCollection<Devise> DeserializeFile()
        {
            ObservableCollection<Devise>? LesDevises=new ObservableCollection<Devise>();
            
            string pathFichier = "Data/Devise.json";
            string jsonString = File.ReadAllText(pathFichier);
            try
            {
                LesDevises = JsonSerializer.Deserialize <ObservableCollection<Devise>>(jsonString);
                foreach (Devise devise in LesDevises) {
                    Console.WriteLine(devise);
                }
            }
            catch (Exception ex) { throw new Exception("Problème de déserialisation"); };
            return LesDevises;
        }
        public void SerializeFile(ObservableCollection<Devise> lesDevises) {

            string pathFichier = "Data/Devise.json";
            string jsonString = File.ReadAllText(pathFichier);
            try
            {
                foreach (Devise devise in lesDevises)
                {
                    jsonString+=JsonSerializer.Serialize<Devise>(devise);
                }
            }
            catch (Exception ex) { throw new Exception("Problème de déserialisation"); };
            File.WriteAllText(pathFichier, jsonString);
        }

       

        public Service()
        {
           
            DeserializeFile();
        }
        
    }
}