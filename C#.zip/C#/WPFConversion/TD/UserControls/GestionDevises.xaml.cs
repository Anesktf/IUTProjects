﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TD.Models;
using TD.Services;

namespace TD.UserControls
{
    /// <summary>
    /// Logique d'interaction pour GestionDevises.xaml
    /// </summary>
    public partial class GestionDevises :UserControl, INotifyPropertyChanged
    {
        private ObservableCollection<Devise> lesDevises = new ObservableCollection<Devise>();

        public event PropertyChangedEventHandler PropertyChanged;

        public Service service = new Service();

        public ObservableCollection<Devise> LesDevises
        {
            get { return lesDevises; }
            set
            {
                this.lesDevises = value;
                OnPropertyChanged("LesDevises");
            }
        }
        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }
        private Devise deviseSelectionnee;
        public Devise DeviseSelectionnee
        {
            get { return deviseSelectionnee; }
            set { deviseSelectionnee=value; }
        }
        public GestionDevises()
        {
            this.InitializeComponent();
            this.DataContext = this;
            LesDevises = service.DeserializeFile();

        }

        private void AjoutDevise_Button_Click(object sender, RoutedEventArgs e)
        {

        }
        
            private void OnButtonClick(object sender, RoutedEventArgs e)
        {

        }
       
        private void MAJFichierJson_Button_Click(object sender, RoutedEventArgs e)
        {
            service.SerializeFile(LesDevises);
        }
    }
}
